// import React, { useEffect, useState } from 'react';

// function SenderDashboard() {
//   const [formData, setFormData] = useState({
//     livestockType: '',
//     quantity: '',
//     source: '',
//     destination: ''
//   });

//   const [shipments, setShipments] = useState([]);
//   const token = localStorage.getItem('token');
//   const senderId = localStorage.getItem('userId');
//   const [statusFilter, setStatusFilter] = useState('All');
//   const name = localStorage.getItem('name');



//   const fetchShipments = async () => {
//     const res = await fetch('http://localhost:5000/api/shipment/all', {
//       headers: {
//         'Authorization': `Bearer ${token}`
//       }
//     });

//     const data = await res.json();
//     if (res.ok) {
//       const myShipments = data.filter((shipment) => (shipment.senderId === senderId) || (shipment.senderId?._id === senderId));
//       setShipments(myShipments);
//     }
//   };

//   useEffect(() => {
//     fetchShipments();
//   }, []);

//   const handleChange = (e) => {
//     setFormData({ ...formData, [e.target.name]: e.target.value });
//   };

//   const handleCreateShipment = async (e) => {
//     e.preventDefault();

//     const res = await fetch('http://localhost:5000/api/shipment/create', {
//       method: 'POST',
//       headers: {
//         'Content-Type': 'application/json',
//         'Authorization': `Bearer ${token}`
//       },
//       body: JSON.stringify({
//         ...formData,
//         receiverId: senderId // ✅ receiver = sender
//       })
//     });

//     if (res.ok) {
//       alert('Shipment created successfully!');
//       setFormData({
//         livestockType: '',
//         quantity: '',
//         source: '',
//         destination: ''
//       });
//       fetchShipments();
//     } else {
//       alert('Error creating shipment');
//     }
//   };

//   const filteredShipments = shipments.filter(s => {
//     if (statusFilter === 'All') return true;
//     return s.status === statusFilter;
//   });

//   const confirmTransporter = async (shipmentId) => {
//     const res = await fetch(`http://localhost:5000/api/shipment/${shipmentId}/confirm`, {
//       method: 'PATCH',
//       headers: {
//         Authorization: `Bearer ${token}`
//       }
//     });

//     const data = await res.json();
//     if (res.ok) {
//       alert('Transporter confirmed!');
//       fetchShipments(); // Refresh list
//     } else {
//       alert(data.error || 'Error confirming transporter');
//       console.log("Sender ID:", senderId);
//       console.log("All Shipments:", data);
//       console.log("Filtered Shipments:", myShipments);

//     }
//   };

//   return (
//     <div className="min-h-screen p-6 bg-gray-100">
//       <h2 className="text-2xl font-bold mb-6 text-center">Sender Dashboard</h2>

//       {/* Shipment Creation Form */}
//       <form onSubmit={handleCreateShipment} className="bg-white p-6 rounded shadow-md max-w-2xl mx-auto mb-10">
//         <h3 className="text-lg font-semibold mb-4">Create New Shipment</h3>
//         <div className="grid grid-cols-2 gap-4">
//           <input name="livestockType" placeholder="Livestock Type" onChange={handleChange} value={formData.livestockType} className="p-2 border rounded" required />
//           <input name="quantity" type="number" placeholder="Quantity" onChange={handleChange} value={formData.quantity} className="p-2 border rounded" required />
//           <input name="source" placeholder="Source Location" onChange={handleChange} value={formData.source} className="p-2 border rounded" required />
//           <input name="destination" placeholder="Destination Location" onChange={handleChange} value={formData.destination} className="p-2 border rounded" required />
//         </div>
//         <button className="mt-4 bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">Create Shipment</button>
//       </form>

//       {/* Shipment List in Cards */}
//       <div className="flex justify-end mb-4 max-w-5xl mx-auto">
//           <select
//             className="p-2 border rounded"
//             value={statusFilter}
//             onChange={(e) => setStatusFilter(e.target.value)}
//           >
//             <option value="All">All</option>
//             <option value="Unassigned">Unassigned</option>
//             <option value="Pending Confirmation">Pending Confirmation</option>
//             <option value="Confirmed">Confirmed</option>
//           </select>
//       </div>
      
      
//       <div className="grid gap-4 max-w-5xl mx-auto">
//         {shipments.length === 0 ? (
//           <p className="text-center text-gray-600">No shipments created yet.</p>
//         ) : (
//           filteredShipments.map((s) => (
//             <div key={s._id} className="bg-white shadow rounded p-4 border-l-4 border-green-500">
//               <div className="flex justify-between items-start">
//                 <div>
//                   <h4 className="text-xl font-bold text-gray-800 mb-1">{s.livestockType} ({s.quantity})</h4>
//                   <p className="text-gray-600 text-sm">From: <strong>{s.source}</strong></p>
//                   <p className="text-gray-600 text-sm">To: <strong>{s.destination}</strong></p>
//                   <p className="text-gray-600 text-sm mt-2">
//                     Status:{" "}
//                     <span
//                       className={`font-semibold ${
//                         s.status === 'Confirmed' ? 'text-green-600' :
//                         s.status === 'Pending Confirmation' ? 'text-yellow-600' :
//                         'text-gray-500'
//                       }`}
//                     >
//                       {s.status}
//                     </span>
//                   </p>
//                 </div>

//                 <div className="text-right">
//                   {s.transporterId ? (
//                     <div className="text-sm text-left">
//                       <p className="font-semibold text-blue-700">{s.transporterId.name}</p>
//                       <p className="text-gray-600">{s.transporterId.email}</p>
//                       {s.transporterId.phone && <p className="text-gray-600">{s.transporterId.phone}</p>}
//                     </div>
//                   ) : (
//                     <p className="text-sm text-gray-400 italic">Not Accepted</p>
//                   )}
//                 </div>
//               </div>

//               {s.status === 'Pending Confirmation' && !s.isConfirmed && (
//                 <button
//                   onClick={() => confirmTransporter(s._id)}
//                   className="mt-4 bg-blue-600 text-white px-4 py-1 rounded hover:bg-blue-700"
//                 >
//                   Confirm Transporter
//                 </button>
//               )}

//               {s.status === 'Confirmed' && (
//                 <p className="mt-4 text-sm text-green-600 font-semibold">Transporter Confirmed ✔</p>
//               )}
//             </div>
//           ))
//         )}
//       </div>
//     </div>
//   );
// }

// export default SenderDashboard;

import React, { useState } from 'react';
import CreateShipment from './CreateShipment';
import ViewShipments from './ViewShipments';

const SenderDashboard = () => {
  const [activeTab, setActiveTab] = useState('create');

  return (
    <div className="flex h-screen">
      {/* Sidebar */}
      <div className="w-64 bg-white border-r shadow-md p-4">
        <h2 className="text-xl font-bold mb-6 text-blue-600">Sender Panel</h2>
        <ul className="space-y-4">
          <li>
            <button onClick={() => setActiveTab('create')} className={`w-full text-left ${activeTab === 'create' ? 'text-blue-600 font-semibold' : 'text-gray-700'}`}>
              Create Shipment
            </button>
          </li>
          <li>
            <button onClick={() => setActiveTab('view')} className={`w-full text-left ${activeTab === 'view' ? 'text-blue-600 font-semibold' : 'text-gray-700'}`}>
              View Shipments
            </button>
          </li>
        </ul>
      </div>

      {/* Main Panel */}
      <div className="flex-1 bg-gray-100 p-6 overflow-y-auto">
        {activeTab === 'create' && <CreateShipment />}
        {activeTab === 'view' && <ViewShipments />}
      </div>
    </div>
  );
};

export default SenderDashboard;
