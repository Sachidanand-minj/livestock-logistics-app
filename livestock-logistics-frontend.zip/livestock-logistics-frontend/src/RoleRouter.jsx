import React, { useEffect, useState } from 'react';
import { Navigate } from 'react-router-dom';
import SenderDashboard from './pages/Dashboard/Sender/SenderDashboard';
import TransporterDashboard from './pages/Dashboard/Transporter/TransporterDashboard';
import AdminDashboard from './pages/Dashboard/Admin/AdminDashboard';
import { toast } from 'react-toastify';

const RoleRouter = () => {
  const [role, setRole] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const storedRole = localStorage.getItem('userRole');
    const name = localStorage.getItem('name');

    if (storedRole) {
      setRole(storedRole);
      toast.success(`Welcome back, ${name || 'User'} 👋`, { autoClose: 1500 });
    }

    setTimeout(() => setLoading(false), 300); // fake loading for smooth UX
  }, []);

  if (loading) {
    return (
      <div className="h-screen flex items-center justify-center bg-gray-100">
        <div className="text-lg font-semibold text-gray-600">Loading dashboard...</div>
      </div>
    );
  }

  switch (role) {
    case 'sender':
    case 'receiver':
      return <SenderDashboard />;
    case 'transporter':
      return <TransporterDashboard />;
    case 'admin':
      return <AdminDashboard />;
    default:
      return <Navigate to="/login" replace />;
  }
};

export default RoleRouter;
